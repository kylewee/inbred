</div>
<!-- END LOGIN -->
<!-- BEGIN COPYRIGHT -->
<div class="copyright">	 
    Powered by <a href="http://rukovoditel.net" target="_new">Rukovoditel</a>
</div>
<!-- END COPYRIGHT -->


<!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>